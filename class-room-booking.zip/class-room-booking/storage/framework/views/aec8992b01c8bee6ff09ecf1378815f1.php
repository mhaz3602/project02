

<?php $__env->startSection('content'); ?>
<div class="container mx-auto">
    <h2 class="text-2xl font-bold mb-4">Riwayat Booking</h2>

    <table class="w-full table-auto border-collapse border border-gray-300">
        <thead class="bg-gray-100">
            <tr>
                <th class="p-3 text-left">Tanggal</th>
                <th class="p-3 text-left">Ruangan</th>
                <th class="p-3 text-left">Jam</th>
                <th class="p-3 text-left">Keperluan</th>
                <th class="p-3 text-left">Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="p-3"><?php echo e(\Carbon\Carbon::parse($r->tanggal)->format('d M Y')); ?></td>
                    <td class="p-3"><?php echo e($r->ruangan->nama ?? '-'); ?></td>
                    <td class="p-3"><?php echo e($r->jam_mulai); ?> - <?php echo e($r->jam_selesai); ?></td>
                    <td class="p-3"><?php echo e($r->keperluan); ?></td>
                    <td class="p-3">
                        <span class="px-3 py-1 rounded-full text-xs font-semibold
                            <?php if($r->status == 'pending'): ?> bg-yellow-100 text-yellow-700
                            <?php elseif($r->status == 'disetujui'): ?> bg-green-100 text-green-700
                            <?php elseif($r->status == 'dibatalkan'): ?> bg-red-100 text-red-700
                            <?php elseif($r->status == 'selesai'): ?> bg-blue-100 text-blue-700
                            <?php endif; ?>">
                            <?php echo e(ucfirst($r->status)); ?>

                        </span>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="p-3 text-center text-gray-500">Belum ada riwayat booking.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project02\class-room-booking\resources\views/booking/riwayat.blade.php ENDPATH**/ ?>