<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Booking Ruangan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Booking Ruangan']); ?>
    <div class="max-w-4xl mx-auto py-10 px-6">
        
        <!-- Judul Halaman -->
        <div class="text-center mb-10">
            <h1 class="text-3xl font-bold text-blue-700 mb-2">📅 Formulir Booking Ruangan</h1>
            <p class="text-gray-500 text-sm">Isi data berikut untuk meminjam ruangan sesuai kebutuhan kegiatanmu!</p>
        </div>

        <!-- Info Ruangan Terpilih -->
        <?php if(isset($ruanganTerpilih)): ?>
            <div class="flex flex-col md:flex-row gap-6 items-start">
                <img src="<?php echo e(asset('images/ruangan/' . $ruanganTerpilih->foto)); ?>" alt="<?php echo e($ruanganTerpilih->nama); ?>"
                     class="w-full md:w-64 h-40 object-cover rounded-lg shadow">
                <div class="flex-1">
                    <h2 class="text-2xl font-bold text-blue-700"><?php echo e($ruanganTerpilih->nama); ?></h2>
                    <p class="text-gray-600">Kapasitas: <?php echo e($ruanganTerpilih->kapasitas); ?> orang</p>
                    <p class="text-gray-600">Lokasi: <?php echo e($ruanganTerpilih->lokasi); ?></p>
                    <?php if($ruanganTerpilih->fasilitas): ?>
                        <p class="text-gray-600">Fasilitas: <?php echo e($ruanganTerpilih->fasilitas); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('booking.store')); ?>" class="space-y-6">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id_ruangan" value="<?php echo e($ruanganTerpilih->id ?? ''); ?>">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Kolom Kiri -->
                <div class="space-y-4">
                    <div>
                        <label for="nama" class="block text-sm font-medium text-gray-700">Nama</label>
                        <input type="text" name="nama" id="nama" required
                            class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <div>
                        <label for="nim" class="block text-sm font-medium text-gray-700">NIM</label>
                        <input type="text" name="nim" id="nim" required
                            class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <div>
                        <label for="no_telp" class="block text-sm font-medium text-gray-700">No. Telepon</label>
                        <input type="text" name="no_telp" id="no_telp" required
                            class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <div>
                        <label for="keperluan" class="block text-sm font-medium text-gray-700">Keperluan</label>
                        <input type="text" name="keperluan" id="keperluan" placeholder="Contoh: Rapat, Diskusi, Seminar" required
                            class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500">
                    </div>
                </div>

                <!-- Kolom Kanan -->
                <div class="space-y-4">
                    <div>
                        <label for="tanggal" class="block text-sm font-medium text-gray-700">Tanggal</label>
                        <input type="date" name="tanggal" id="tanggal" required
                            class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <div>
                        <label for="jam_mulai" class="block text-sm font-medium text-gray-700">Jam Mulai</label>
                        <input type="time" name="jam_mulai" id="jam_mulai" required
                            class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <div>
                        <label for="jam_selesai" class="block text-sm font-medium text-gray-700">Jam Selesai</label>
                        <input type="time" name="jam_selesai" id="jam_selesai" required
                            class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500">
                    </div>
                </div>
            </div>

            <div class="text-end pt-4">
                <button type="submit"
                        class="bg-blue-600 text-white font-semibold px-6 py-2 rounded hover:bg-blue-700 transition">
                    Booking Sekarang
                </button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\project02\class-room-booking\resources\views/booking/create.blade.php ENDPATH**/ ?>