<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Kalender Booking Ruangan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Kalender Booking Ruangan']); ?>
    <div class="p-6 space-y-6 bg-gradient-to-br from-blue-50 via-white to-blue-100 min-h-screen font-sans">

        <?php
            $prev = $tanggal->copy()->subMonth();
            $next = $tanggal->copy()->addMonth();
            $hariPertama = $tanggal->copy()->startOfMonth()->dayOfWeek;
            $jumlahHari = $tanggal->daysInMonth;
        ?>

        <!-- Navigasi Bulan -->
        <div class="flex justify-between items-center mb-6">
            <a href="<?php echo e(route('kalender', ['bulan' => $prev->month, 'tahun' => $prev->year])); ?>"
               class="text-sm px-4 py-2 bg-white border border-blue-300 rounded-full shadow hover:bg-blue-50 transition font-medium text-blue-700">
               ← <?php echo e($prev->translatedFormat('F')); ?>

            </a>

            <h1 class="text-2xl font-bold text-blue-800 tracking-tight">
                <?php echo e($tanggal->translatedFormat('F Y')); ?>

            </h1>

            <a href="<?php echo e(route('kalender', ['bulan' => $next->month, 'tahun' => $next->year])); ?>"
               class="text-sm px-4 py-2 bg-white border border-blue-300 rounded-full shadow hover:bg-blue-50 transition font-medium text-blue-700">
               <?php echo e($next->translatedFormat('F')); ?> →
            </a>
        </div>

        <!-- Header Hari -->
        <div class="grid grid-cols-7 gap-2 text-center font-semibold text-gray-700">
            <?php $__currentLoopData = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-blue-200/50 py-2 rounded-lg shadow-sm text-sm">
                    <?php echo e($day); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Tanggal -->
        <div class="grid grid-cols-7 gap-2">
            <?php for($i = 0; $i < $hariPertama; $i++): ?>
                <div></div>
            <?php endfor; ?>

            <?php for($tgl = 1; $tgl <= $jumlahHari; $tgl++): ?>
                <?php
                    $isBooked = isset($bookings[$tgl]);
                ?>

                <div class="p-3 rounded-xl border transition-all duration-300 min-h-[100px] relative group
                    <?php echo e($isBooked ? 'bg-blue-100 border-blue-400 text-blue-900 shadow-md' : 'bg-white border-gray-200 text-gray-500 hover:border-blue-300 hover:shadow-md'); ?>">
                    
                    <!-- Tanggal -->
                    <div class="text-base font-bold"><?php echo e($tgl); ?></div>

                    <?php if($isBooked): ?>
                        <ul class="mt-2 space-y-1">
                            <?php $__currentLoopData = $bookings[$tgl]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-xs bg-blue-50 text-blue-800 rounded px-2 py-1 shadow-sm">
                                    <?php echo e($b->nama); ?><br>
                                    <span class="font-medium">
                                        <?php echo e(\Carbon\Carbon::parse($b->jam_mulai)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($b->jam_selesai)->format('H:i')); ?>

                                    </span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="absolute top-2 right-2 text-lg animate-bounce">📌</div>
                    <?php else: ?>
                        <div class="mt-3 text-xs italic group-hover:text-blue-700 transition">
                            Belum ada booking
                        </div>
                        <div class="absolute top-2 right-2 text-lg">📅</div>
                    <?php endif; ?>
                </div>
            <?php endfor; ?>
        </div>

        <!-- Footer -->
        <footer class="text-xs text-center text-gray-500 mt-10 italic">
            Gunakan kalender ini untuk memantau ketersediaan ruangan setiap harinya.
        </footer>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\project02\class-room-booking\resources\views/kalender/index.blade.php ENDPATH**/ ?>