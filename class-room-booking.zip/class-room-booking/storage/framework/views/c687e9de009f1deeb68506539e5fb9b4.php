<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard']); ?>
    <div class="p-6 bg-gradient-to-br from-blue-50 via-white to-blue-100 min-h-screen">

        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-white/90 p-8 rounded-2xl shadow-2xl backdrop-blur-sm">

            
            <div class="relative group overflow-hidden rounded-xl">

                
                <div class="absolute -top-16 left-1/2 transform -translate-x-1/2 z-10">
                    <img src="<?php echo e(asset('images/ilustrasi-laptop.png')); ?>" alt="Ilustrasi Mahasiswa"
                         class="w-32 h-32 animate-pulse drop-shadow-lg">
                </div>

                
                <img src="<?php echo e(asset('images/ruangan.jpeg')); ?>"
                     alt="Ruangan"
                     class="rounded-xl w-full h-auto transform group-hover:scale-105 transition duration-300 ease-in-out shadow-md mt-16">

                
                <div class="absolute -top-5 -left-5 w-20 h-20 bg-blue-300/30 rounded-full blur-xl"></div>
                <div class="absolute bottom-2 right-2 w-14 h-14 bg-blue-200/40 rounded-full blur-md"></div>

                
                <div class="absolute top-2 right-2 text-4xl animate-bounce">🎓</div>
            </div>

            
            <div>
                <h2 class="text-3xl font-extrabold text-blue-800 mb-4 drop-shadow">
                    Halo Mahasiswa 👋
                </h2>

                <p class="text-gray-700 text-base mb-6 leading-relaxed text-justify">
                    Aplikasi ini hadir sebagai solusi simpel dan cerdas untuk kamu yang butuh ruangan untuk kegiatan akademik maupun non-akademik. Mulai dari diskusi kelompok, seminar/workshop mini, hingga rapat mendadak bareng dosen atau teman-teman organisasi, semua bisa kamu atur lewat sistem ini tanpa ribet! 📚
                </p>

                
                <blockquote class="italic text-sm text-gray-500 bg-blue-50 px-4 py-2 rounded-md mb-6 border-l-4 border-blue-400">
                    “Belajar itu berat... Tapi rebutan ruangan lebih berat.” 😅
                </blockquote>

                <h4 class="text-xl font-semibold mb-3 text-blue-700">Syarat Peminjaman:</h4>
                <ul class="space-y-2 text-gray-700">
                    <?php $__currentLoopData = [ 
                        'Mahasiswa aktif STT-NF',
                        'Peminjaman minimal H-1 sebelum penggunaan',
                        'Data harus lengkap dan benar',
                        'Ruangan tidak sedang digunakan'
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $syarat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex items-start gap-2">
                        <svg class="w-5 h-5 text-green-500 mt-1" fill="none" stroke="currentColor" stroke-width="2"
                             viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                        <?php echo e($syarat); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                
                <div class="mt-6">
                    <a href="<?php echo e(route('ruangan.index')); ?>"
                       class="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-blue-500 to-blue-700 text-white px-6 py-2 rounded-xl text-sm font-semibold shadow-md hover:from-blue-600 hover:to-blue-800 transition-all duration-300">
                        🚀 Booking Sekarang →
                    </a>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\project02\class-room-booking\resources\views/dashboard.blade.php ENDPATH**/ ?>