<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Daftar Ruangan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Daftar Ruangan']); ?>
    <div class="p-6 space-y-10 bg-blue-50 min-h-screen">
        
        <!-- Judul -->
        <div class="text-center space-y-1">
            <h2 class="text-4xl font-extrabold text-blue-700 tracking-wide inline-block relative drop-shadow-sm">
                <span class="relative z-10 px-4">Daftar Ruangan Tersedia</span>
                <span class="absolute left-1/2 -translate-x-1/2 bottom-0 w-1/2 h-1 bg-blue-200 rounded-full blur-sm"></span>
            </h2>
            <p class="text-sm text-gray-500">
                Pilih ruangan terbaikmu, klik <span class="font-medium">"Pinjam Ruangan"</span> & nikmati kemudahan akses!
            </p>
        </div>

        <!-- Grid Ruangan -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
            <?php $__empty_1 = true; $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    if (Str::contains(Str::lower($r->nama), ['kelas'])) {
                        $emoji = '🏫';
                    } elseif (Str::contains(Str::lower($r->nama), ['rapat', 'dosen'])) {
                        $emoji = '👨‍🏫';
                    } elseif (Str::contains(Str::lower($r->nama), ['audit', 'auditorium'])) {
                        $emoji = '🎤';
                    } elseif (Str::contains(Str::lower($r->nama), ['rooftop', 'perpus', 'library'])) {
                        $emoji = '📚';
                    } else {
                        $emoji = '🏢';
                    }

                    $badge = $r->kapasitas >= 100 ? 'bg-red-100 text-red-600' :
                             ($r->kapasitas >= 40 ? 'bg-yellow-100 text-yellow-700' :
                             'bg-green-100 text-green-700');
                ?>

                <div class="flex flex-col bg-white/80 backdrop-blur-lg border border-gray-200 rounded-2xl shadow-md hover:shadow-2xl hover:border-blue-400 transition-all duration-300 transform hover:-translate-y-1 h-full min-h-[470px]">
                    
                    <!-- Gambar -->
                    <div class="relative overflow-hidden rounded-t-2xl">
                        <img src="<?php echo e(asset('images/ruangan/' . $r->foto)); ?>" alt="<?php echo e($r->nama); ?>"
                             class="w-full h-48 object-cover transition-transform duration-300 hover:scale-110 brightness-95">
                        <div class="absolute top-3 left-3 bg-blue-500 text-white text-xs px-3 py-1 rounded-full shadow-sm">
                            Tersedia
                        </div>
                        <div class="absolute top-3 right-3 text-2xl animate-bounce"><?php echo e($emoji); ?></div>
                    </div>

                    <!-- Konten -->
                    <div class="flex flex-col justify-between flex-grow p-5 bg-gradient-to-br from-white via-white to-blue-50 rounded-b-2xl">
                        <div class="space-y-3 mb-4">
                            <div class="min-h-[3.5rem]">
                                <h3 class="text-lg font-bold text-gray-800 break-words leading-tight text-left">
                                    <?php echo e($r->nama); ?>

                                </h3>
                            </div>

                            <span class="inline-block px-3 py-1 text-xs font-semibold rounded-full <?php echo e($badge); ?>">
                                Kapasitas: <?php echo e($r->kapasitas); ?> orang
                            </span>

                            <div class="flex items-start gap-3">
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-map-pin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-gray-400 mt-0.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                                <p class="text-sm text-gray-700 leading-snug break-words">
                                    <?php echo e($r->lokasi); ?>

                                </p>
                            </div>

                            <?php if($r->fasilitas): ?>
                                <div class="flex items-start gap-3">
                                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-cog-6-tooth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-gray-400 mt-0.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                                    <p class="text-sm text-gray-700 leading-snug break-words">
                                        <?php echo e($r->fasilitas); ?>

                                    </p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Tombol -->
                        <div>
                            <a href="<?php echo e(route('booking.create', ['ruangan' => $r->id])); ?>"
                               class="w-full inline-flex items-center justify-center gap-2 bg-gradient-to-r from-blue-500 to-blue-700 text-white text-sm font-semibold px-4 py-2 rounded-xl hover:from-blue-600 hover:to-blue-800 transition-all duration-300 shadow-md hover:scale-[1.02]">
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-calendar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                                <span>Pinjam Ruangan</span>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-full text-center text-gray-500 py-24">
                    <p class="text-2xl font-semibold">📭 Belum ada ruangan yang tersedia saat ini.</p>
                    <p class="text-sm mt-2">Silakan kembali lagi nanti ya!</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Footer -->
        <footer class="text-xs text-center text-gray-400 mt-16 italic">
            Sistem ini dibuat untuk memudahkan peminjaman ruangan. Gunakan dengan bijak dan tanggung jawab ya! 🙏
        </footer>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\project02\class-room-booking\resources\views/ruangan/index.blade.php ENDPATH**/ ?>