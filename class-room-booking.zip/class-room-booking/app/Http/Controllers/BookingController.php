<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Ruangan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BookingController extends Controller
{
    public function index()
    {
        $booking = Booking::with('ruangan')->latest()->get();
        return view('booking.index', compact('booking'));
    }

    public function create(Request $request)
    {
        $ruanganTerpilih = null;

        if ($request->has('ruangan')) {
            $ruanganTerpilih = Ruangan::find($request->ruangan);
        }

        return view('booking.create', compact('ruanganTerpilih'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_ruangan' => 'required|exists:ruangan,id',
            'nama' => 'required|string|max:100',
            'nim' => 'required|string|max:30',
            'no_telp' => 'required|string|max:20',
            'tanggal' => 'required|date',
            'jam_mulai' => 'required',
            'jam_selesai' => 'required|after:jam_mulai',
            'keperluan' => 'required|string|max:100',
        ]);

        // Cek bentrok booking
        $bentrok = Booking::where('id_ruangan', $request->id_ruangan)
            ->where('tanggal', $request->tanggal)
            ->where(function ($query) use ($request) {
                $query->whereBetween('jam_mulai', [$request->jam_mulai, $request->jam_selesai])
                      ->orWhereBetween('jam_selesai', [$request->jam_mulai, $request->jam_selesai]);
            })
            ->exists();

        if ($bentrok) {
            return back()->with('error', 'Jadwal bentrok dengan booking lain.');
        }

        // Simpan data booking
        Booking::create([
            'id_ruangan' => $request->id_ruangan,
            'id_mahasiswa' => Auth::id(), // pastikan user login
            'nama' => $request->nama,
            'nim' => $request->nim,
            'no_telp' => $request->no_telp,
            'tanggal' => $request->tanggal,
            'jam_mulai' => $request->jam_mulai,
            'jam_selesai' => $request->jam_selesai,
            'keperluan' => $request->keperluan,
            'status' => 'pending',
        ]);

        return redirect()->route('booking.riwayat')->with('success', 'Booking berhasil diajukan!');
    }

    public function riwayat()
    {
        $riwayat = Booking::with('ruangan')->orderByDesc('created_at')->get();
        return view('booking.riwayat', compact('riwayat'));
    }

    // Tambahan resource method jika perlu
    public function show(Booking $booking)
    {
        return view('booking.show', compact('booking'));
    }

    public function edit(Booking $booking)
    {
        return view('booking.edit', compact('booking'));
    }

    public function update(Request $request, Booking $booking)
    {
        $booking->update($request->all());
        return redirect()->route('booking.index')->with('success', 'Booking diperbarui.');
    }

    public function destroy(Booking $booking)
    {
        $booking->delete();
        return redirect()->route('booking.index')->with('success', 'Booking dihapus.');
    }
}
