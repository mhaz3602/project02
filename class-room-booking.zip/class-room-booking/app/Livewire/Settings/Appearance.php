<?php

namespace App\Livewire\Settings;

use Livewire\Component;

class Appearance extends Component
{
    //
}
